# TrustHub — MVP

Une plateforme de confiance basée sur des preuves réelles : les clients ne cherchent pas
seulement un maçon, un développeur ou un électricien — ils cherchent quelqu'un dont la
fiabilité est **prouvée**, pas seulement affirmée.

---

## 1. Pourquoi cette architecture ?

```
trusthub/
├── app.py                  # Application factory : crée et configure l'app Flask
├── config.py               # Tous les réglages centralisés (clé secrète, DB, uploads)
├── extensions.py           # db et login_manager, créés hors de app.py (évite les imports circulaires)
├── models.py                # Les 9 tables SQLAlchemy et leurs relations
├── utils.py                 # Logique métier réutilisable (upload sécurisé, calcul du score)
├── seed.py                  # Génère les données de démonstration (5 pros + admin + client)
├── requirements.txt
├── routes/
│   ├── main.py               # Page d'accueil
│   ├── auth.py                # Inscription / connexion / déconnexion
│   ├── users.py               # Tableaux de bord (redirection selon le rôle)
│   ├── professionals.py        # Recherche, profils, preuves, cycle de prestation
│   └── admin.py                # Validation des preuves par l'administrateur
├── templates/                # Un fichier HTML par page, tous héritent de base.html
├── static/
│   ├── css/style.css           # Design mobile-first
│   ├── js/main.js               # JS minimal (pas de framework)
│   └── uploads/                  # Fichiers de preuves uploadés
└── database/trusthub.db          # Fichier SQLite (créé automatiquement)
```

**Pourquoi découper les routes en blueprints (`routes/*.py`) plutôt qu'un seul fichier ?**
Chaque blueprint a une responsabilité claire. `professionals.py` concentre à lui seul
tout le cœur métier (recherche, profil, preuves, cycle de la prestation) car c'est
la partie qui évoluera le plus ; séparer `auth.py` et `admin.py` permet de les faire
évoluer (ou de les sécuriser) indépendamment sans relire tout le reste.

**Pourquoi l'"Application Factory" (`create_app()`) plutôt que `app = Flask(__name__)` direct ?**
Cela évite les imports circulaires : `models.py` a besoin de `db`, les routes ont besoin
de `db` et des modèles, et `app.py` a besoin des routes. En créant `db` dans un fichier
séparé (`extensions.py`) puis en l'attachant à l'app avec `db.init_app(app)` seulement
dans `create_app()`, chaque fichier peut importer ce dont il a besoin sans dépendance
circulaire. Cela permet aussi de créer facilement une seconde instance de l'app plus
tard (par exemple avec une base de test en mémoire).

---

## 2. Comment fonctionne le score de confiance ?

TrustHub ne pose pas les mêmes questions à tout le monde, parce que la confiance
ne se prouve pas de la même façon selon ce qu'on évalue. Chaque catégorie a un
**type** (`Category.category_type`) :

### Prestataire (maçon, plombier, développeur, professeur...)
On évalue un **travail**. Trois critères, posés au client après confirmation :

| Critère | Ce qu'il mesure |
|---|---|
| Qualité du travail | La qualité technique du résultat |
| Respect des délais | Le délai promis a-t-il été tenu ? |
| Fiabilité paiement | **Une fois payé, a-t-il bien terminé le travail sans disparaître ?** |

Le troisième critère n'est volontairement **pas une note de 1 à 5** mais une
réponse factuelle "oui/non" (`Review.fiabilite_paiement`) : c'est la question
la plus importante de tout le système, parce qu'elle protège directement les
clients contre le scénario le plus dangereux — payer quelqu'un qui disparaît
sans finir le travail. Un seul "non" déclenche un **signalement grave** :

- Le score du professionnel est immédiatement plafonné à 30/100.
- Son statut retombe à "non vérifié", quels que soient ses avis précédents.
- Le profil affiche un avertissement visible partout (page publique, son
  propre tableau de bord).
- Le cas apparaît dans `/admin` → section "⚠️ Signalements de paiement", et
  **seul un administrateur** peut lever le signalement après vérification
  (bouton "Lever le signalement (vérifié, non fondé)"). Une fois levé, les
  anciens avis concernés ne reviennent jamais hanter le score automatiquement :
  seuls les avis postérieurs à la levée comptent à nouveau pour ce critère
  (voir `ProfessionalProfile.payment_complaint_cleared_at` dans `models.py`).

### Vendeur (boutique, revendeur de matériaux, de véhicules...)
On évalue un **produit**. Deux critères :

| Critère | Ce qu'il mesure |
|---|---|
| Qualité des produits | La qualité perçue de ce qui a été vendu |
| Prix abordables | Le prix était-il raisonnable pour ce qui a été reçu ? |

### Calcul commun aux deux types

Chaque critère noté de 1 à 5 est converti en pourcentage, moyenné sur tous les
avis du professionnel. Le score global est la moyenne des critères pertinents
pour son type, plus un petit bonus de crédibilité (jusqu'à +5 points) lié au
nombre de preuves validées par un administrateur, plafonné à 100 — sauf en cas
de signalement de paiement actif, où le plafond de 30 prime sur tout le reste.

### Un avis ne peut jamais exister sans une vraie prestation

C'est la garantie centrale du système, portée par le cycle de vie de `Project` :

```
demandee → acceptee → confirmee → avis_laisse
       ↘ refusee
```

- Le **client** envoie une demande (`demandee`).
- Le **professionnel** accepte ou refuse.
- Seul le **client** peut ensuite confirmer que le travail a été fait (ou la
  commande reçue, pour un vendeur).
- L'avis n'est possible **qu'après** cette confirmation, et une seule fois par
  prestation.

Cela empêche un professionnel de se noter lui-même, ou un tiers de laisser un
faux avis : il faut être passé par tout le cycle.

### La progression du statut

```
non_verifie  →  verifie  →  recommande
```

- **Non vérifié** : profil créé, aucune preuve validée (ou signalement de
  paiement actif — voir plus haut).
- **Vérifié** : dès qu'au moins une preuve a été validée par un administrateur.
- **Recommandé** : dès que 5 prestations sont confirmées **et** que le score
  dépasse 80/100.

Ces transitions sont automatiques (`utils.update_verification_status`),
déclenchées à chaque validation de preuve ou recalcul de score — jamais une
rétrogradation automatique en dehors du signalement de paiement : en cas
d'abus, seul un administrateur peut faire redescendre un professionnel.

## 3. Comment lancer le projet

```bash
cd trusthub
pip install -r requirements.txt

# Génère les données de démonstration (admin, client, 5 professionnels avec preuves et avis)
python seed.py

# Lance le serveur, accessible sur tout le réseau local (0.0.0.0)
python app.py
```

L'application est servie sur `http://127.0.0.1:5000`.

**Comptes de démonstration** (créés par `seed.py`) :

| Rôle | Email | Mot de passe |
|---|---|---|
| Admin | `admin@trusthub.dev` | `admin123` |
| Client | `client@trusthub.dev` | `client123` |
| Professionnels (7) | ex: `moussa.diop@example.com` | `demo1234` |
| Vendeur (exemple) | `awa.sow@example.com` | `demo1234` |
| Signalement de paiement (exemple) | `modou.kane@example.com` | `demo1234` |

Pour repartir d'une base vide : `python seed.py --reset`.

---

## 4. TrustHub est une PWA — comment la tester avec de vrais utilisateurs

TrustHub est maintenant une **Progressive Web App** : elle peut s'installer sur
l'écran d'accueil (icône, lancement en plein écran, sans barre d'adresse), et
un service worker (`static/sw.js`) lui permet d'afficher une page de secours
plutôt qu'un écran blanc en cas de coupure réseau. Fichiers concernés :
`static/manifest.json`, `static/sw.js`, `static/icons/`, et les balises PWA
dans `templates/base.html`.

### ⚠️ Point important : HTTPS est obligatoire pour l'installation complète

Les navigateurs n'activent les service workers (et donc l'installabilité réelle)
que dans un "contexte sécurisé" : HTTPS, ou `http://localhost` en local. Une
adresse de type `http://192.168.1.24:5000` (Wi-Fi local, ce que suggère le
cahier des charges initial) **ne suffit pas** : le service worker ne s'enregistrera
pas, et Chrome ne proposera jamais le bouton "Installer". Deux options pour
tester avec de vrais utilisateurs :

**Option A — Recommandée : un tunnel HTTPS public (ngrok)**

C'est la façon la plus simple d'obtenir une vraie installation PWA, testable
par n'importe qui, même en dehors de votre Wi-Fi :

```bash
python app.py                 # dans un premier terminal
ngrok http 5000                # dans un second terminal (après avoir créé un compte gratuit sur ngrok.com)
```

`ngrok` affiche une URL du type `https://xxxx.ngrok-free.app` : partagez-la à
vos testeurs. Elle est en HTTPS valide, donc l'installation complète (icône,
service worker, bouton "Installer") fonctionne exactement comme en production.

**Option B — Test rapide sur le même Wi-Fi (sans installation complète)**

Utile pour vérifier rapidement l'interface sur votre propre téléphone pendant
le développement, mais **sans** service worker ni bouton d'installation actif :

1. Téléphone et ordinateur sur le même Wi-Fi.
2. Trouvez l'IP locale de l'ordinateur (`ip addr` / `ifconfig` sur macOS/Linux,
   `ipconfig` sur Windows).
3. `python app.py` (déjà configuré avec `host="0.0.0.0"`).
4. Sur le téléphone : `http://<IP_DE_L_ORDINATEUR>:5000`.

### Comment l'installer une fois sur une URL HTTPS

- **Android (Chrome)** : une bannière "Installer" apparaît automatiquement en
  bas de l'écran (générée par `beforeinstallprompt`, voir `static/js/main.js`).
  Un appui suffit ; l'icône TrustHub apparaît ensuite sur l'écran d'accueil.
- **iOS (Safari)** : Safari ne propose jamais de bouton d'installation
  automatique (Apple ne déclenche pas `beforeinstallprompt`). TrustHub affiche
  donc à la place une bannière d'instructions : *Partager → "Sur l'écran
  d'accueil"*.

Le design reste mobile-first (barre de navigation en bas façon app native,
formulaires et cartes optimisés pour un écran étroit) : que l'app soit ouverte
dans le navigateur ou installée en PWA, l'expérience est la même.

---

## 5. Faire évoluer vers une application mobile native

Le code a été organisé pour rendre cette transition simple :

- **Séparer l'API du HTML** : la logique métier (`models.py`, `utils.py`, le cycle de
  `Project`) est déjà indépendante des templates Jinja2. L'étape suivante consiste à
  exposer les mêmes routes en JSON (avec `flask-restful` ou en renvoyant simplement
  `jsonify(...)` au lieu de `render_template(...)`), sans toucher aux modèles.
- **Authentification** : remplacer les sessions Flask-Login par des tokens JWT pour
  que l'app mobile s'authentifie sans cookies de navigateur.
- **Frontend natif** : une fois l'API JSON en place, un frontend React Native ou
  Flutter peut consommer exactement les mêmes données (recherche, profils, score de
  confiance, cycle de prestation) sans changement côté serveur.
- **Base de données** : SQLite convient au MVP, mais pour la production, changer
  uniquement `SQLALCHEMY_DATABASE_URI` vers PostgreSQL suffit — SQLAlchemy abstrait
  le reste.

---

## 6. Sécurité — ce qui est en place et pourquoi

Cette section résume un audit volontaire de l'application. Rien n'est laissé
"pour plus tard" concernant les points ci-dessous : ils sont actifs dès
aujourd'hui, même en test avec de vrais utilisateurs.

**Protection CSRF (Flask-WTF)** — TOUS les formulaires POST de l'application
incluent un jeton `{{ csrf_token() }}` cryptographique, vérifié automatiquement
par `CSRFProtect` (voir `extensions.py`). Sans ce jeton, une requête POST est
rejetée (code 400). Cela empêche un site malveillant de faire agir un
utilisateur connecté à son insu (ex : valider une preuve, changer un statut).

**Anti brute-force (Flask-Limiter)** — `/login` est limité à 10 tentatives par
minute et par IP, `/register` à 10 comptes par heure et par IP (voir
`routes/auth.py`). Cela ralentit fortement une tentative de deviner un mot de
passe ou de créer des centaines de faux comptes.

**En-têtes de sécurité HTTP** (voir `app.py` → `set_security_headers`) sur
chaque réponse : `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`
(anti-clickjacking), `Referrer-Policy`, et une `Content-Security-Policy` qui
n'autorise les scripts que depuis TrustHub lui-même.

**Cookies de session durcis** : `HttpOnly` (inaccessibles en JavaScript, donc
inutilisables même via une faille XSS), `SameSite=Lax` (bloque leur envoi
depuis un site tiers), et `Secure` (HTTPS uniquement) activable via la
variable d'environnement `FORCE_SECURE_COOKIES=true` dès que l'app tourne
derrière une URL HTTPS (ex : ngrok — voir section PWA).

**Aucune information sensible visible publiquement** — la page de connexion
n'affiche plus aucun identifiant de démonstration (admin ou autre) : ces
identifiants restent uniquement dans ce README, jamais dans l'interface
elle-même. Un compte administrateur ne peut de toute façon jamais être créé
depuis le formulaire d'inscription public (`routes/auth.py` refuse le rôle
"admin").

**Mode debug désactivé par défaut** — le débogueur interactif de Werkzeug
(activé par `debug=True`) permet l'**exécution de code arbitraire** à
quiconque provoque une erreur sur le serveur. Il est décrit dans `app.py`
avec un avertissement explicite et ne s'active que si la variable
d'environnement `FLASK_DEBUG=true` est définie volontairement en local.
**Ne l'activez jamais** sur une instance exposée via ngrok ou toute autre URL
publique.

**Autres protections déjà présentes** :
- Mots de passe hashés (`werkzeug.security`), jamais stockés en clair.
- Vérification d'extension **avant** tout traitement de fichier uploadé
  (`utils.allowed_file`), noms de fichiers rendus uniques (`uuid4`) pour éviter
  les écrasements ou les chemins traversants (`../../etc/passwd`).
- Limite de taille des fichiers (8 Mo, `MAX_CONTENT_LENGTH`).
- Permissions par rôle : décorateur `admin_required`, vérifications
  `current_user.role` dans chaque route sensible, `abort(403)` systématique.
- Message d'erreur de connexion identique que l'email existe ou non (empêche
  un attaquant d'énumérer les comptes inscrits).
- Les numéros de téléphone/WhatsApp des professionnels (voir section 10) ne
  sont visibles que par des clients connectés, jamais par un visiteur anonyme
  ou un robot d'indexation — pour limiter le harcèlement commercial.

**Ce qui reste à ajouter avant une vraie mise en production** (au-delà du
test avec des utilisateurs) : rotation de `SECRET_KEY`, sauvegarde chiffrée
de la base de données, audit antivirus des fichiers uploadés si le volume le
justifie, et un stockage partagé (Redis) pour Flask-Limiter si l'app tourne
un jour sur plusieurs serveurs.

---

## 7. Une plateforme multi-secteurs, pas seulement le bâtiment

TrustHub ne se limite pas à un métier : n'importe qui doit pouvoir trouver une
personne fiable, que ce soit pour construire une maison ou pour acheter un
produit. Les catégories (`Category`) sont donc regroupées par **secteur**
(`Category.sector`) :

- **Bâtiment & Construction** : architecte, maçon, plombier, électricien,
  menuisier bois, menuisier métallique/soudeur, peintre, carreleur, couvreur.
- **Artisanat & Réparation** : réparateur électroménager, mécanicien, couturier.
- **Commerce & Vente** : vendeur de matériaux, d'électroménager, de véhicules,
  boutiques — parce qu'acheter un produit fiable mérite autant de confiance
  que d'engager un artisan.
- **Éducation & Formation**, **Technologie & Digital**, **Services à la
  personne**, et d'autres secteurs ajoutables à tout moment.

**L'administrateur peut ajouter un nouveau métier ou un nouveau secteur
directement depuis `/admin/categories`**, sans toucher au code : c'est ce qui
permet à TrustHub de s'étendre progressivement à "tous les secteurs où les
gens ont besoin de faire confiance", comme le dit le cahier des charges,
sans avoir à redéployer l'application à chaque nouveau métier. À la création
d'un métier, l'administrateur choisit aussi son **type** — prestataire ou
vendeur — qui détermine les critères d'avis proposés (voir section 2).

Sur l'accueil et dans la recherche, le choix se fait en deux temps
(secteur → métier) via des `<optgroup>` : avec des dizaines de métiers
possibles, un unique menu plat serait illisible sur un écran de téléphone.

## 8. Contacter un professionnel : appel, WhatsApp ou email

Un client connecté voit, en haut du profil de chaque professionnel, trois
boutons de contact **direct** :

- **📞 Appeler** — ouvre l'application téléphone (`tel:`) avec le numéro du
  professionnel déjà composé.
- **💬 WhatsApp** — ouvre une conversation WhatsApp (`https://wa.me/...`) avec
  le numéro WhatsApp du professionnel (ou son téléphone si aucun numéro
  WhatsApp distinct n'a été renseigné).
- **✉️ Email** — ouvre le client mail (`mailto:`) avec l'adresse du compte du
  professionnel.

Ces boutons ne s'affichent qu'aux **clients connectés** : ni un visiteur
anonyme, ni un robot d'indexation ne peuvent récupérer ces numéros (voir
section 6, sécurité).

Le formulaire "Suivre cette prestation sur TrustHub" reste disponible en bas
de la page, mais devient volontairement secondaire : c'est un choix
délibéré. Le contact réel (négocier, expliquer le besoin, convenir d'un prix)
se fait par les canaux ci-dessus, comme dans la vraie vie ; le suivi
TrustHub sert uniquement à formaliser ensuite la prestation pour permettre un
avis vérifié (voir section 2 — sans ce suivi, un avis ne peut pas exister).

Le téléphone est **obligatoire** pour qu'un professionnel publie sa fiche
(voir `routes/professionals.py` → `setup_profile`) : un profil sans moyen de
contact réel n'aurait aucune valeur pour un client.

---

## 9. Corrections de responsive design

Deux bugs ont été corrigés :

- **Débordement sur la page admin** : le formulaire "refuser une preuve"
  combinait un champ texte et un bouton dans une même ligne flex. Par défaut,
  un `<input>` refuse de rétrécir sous sa largeur naturelle (`min-width: auto`),
  ce qui poussait le bouton hors de l'écran sur les téléphones étroits.
  Correction : `min-width: 0` sur les champs + `flex-wrap: wrap` sur la ligne,
  pour que le bouton passe à la ligne plutôt que de déborder si la place
  manque vraiment.
- **Responsive imparfait ailleurs** : le même correctif (`min-width: 0` +
  `flex-wrap: wrap`) a été appliqué à tous les groupes de boutons, filtres
  de recherche et boutons radio. Les badges de statut ne rétrécissent plus
  jamais (`flex-shrink: 0`) pour ne pas se déformer. Un filet de sécurité
  global (`overflow-x: hidden` + `overflow-wrap: break-word`) empêche tout
  texte ou mot très long (email, nom composé) de forcer un scroll horizontal.
  Une media query `≤360px` resserre les marges sur les téléphones les plus
  étroits.
- **Texte trop petit** : la taille de police de base est maintenant fixée
  explicitement à 16px (au lieu de dépendre du réglage par défaut du
  navigateur), et toutes les tailles de texte secondaires (labels, badges,
  texte des cartes, boutons...) ont été relevées de 1 à 2px pour une lecture
  confortable, sans loupe, comme dans une vraie application. Le zoom
  (pincer-zoomer) n'est plus bloqué (`maximum-scale=5` au lieu de `1` dans
  le viewport) : c'était un obstacle d'accessibilité en plus d'aggraver le
  problème pour les personnes qui ont besoin d'agrandir le texte.

---

## 10. Ce qui reste volontairement simple dans ce MVP

- Pas de messagerie intégrée entre client et professionnel (la demande contient une
  simple description ; à enrichir avec un vrai fil de discussion plus tard).
- Pas de paiement en ligne (hors périmètre du MVP, cf. cahier des charges).
- Pas de notifications push (le service worker actuel gère l'installation et un
  repli hors-ligne basique, mais pas encore les Web Push — cela demande un
  serveur de clés VAPID et l'accord explicite de l'utilisateur).
- Le service worker met en cache l'app shell et les pages déjà visitées, mais ne
  synchronise pas de données créées hors-ligne (pas de Background Sync) : une
  action tentée sans réseau échouera proprement plutôt que de sembler réussir.
- Le tableau de bord admin est fonctionnel mais minimal (pas de gestion fine des
  abus/signalements — à construire une fois les premiers usages réels observés).
