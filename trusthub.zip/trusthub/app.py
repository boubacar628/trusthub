import os

from flask import Flask, render_template

from config import Config
from extensions import db, login_manager, csrf, limiter
from models import User


def create_app(config_class=Config):
    """
    Pattern "Application Factory" : au lieu de créer l'objet Flask directement
    au niveau du module (ce que font beaucoup de tutoriels), on l'encapsule
    dans une fonction. Avantages concrets pour TrustHub :
      - on peut créer plusieurs instances de l'app avec des configs différentes
        (ex: une config de test avec une base SQLite en mémoire) ;
      - cela évite les imports circulaires entre app.py, models.py et
        les blueprints, puisque db/login_manager existent indépendamment
        de l'app tant qu'on n'a pas appelé db.init_app(app).
    """
    app = Flask(__name__)
    app.config.from_object(config_class)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    os.makedirs(os.path.dirname(app.config["SQLALCHEMY_DATABASE_URI"].replace("sqlite:///", "")), exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)       # protection CSRF sur tous les formulaires (voir extensions.py)
    limiter.init_app(app)    # anti brute-force sur /login et /register

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    # --- Enregistrement des blueprints ---------------------------------
    from routes.main import main_bp
    from routes.auth import auth_bp
    from routes.users import users_bp
    from routes.professionals import professionals_bp
    from routes.admin import admin_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(professionals_bp)
    app.register_blueprint(admin_bp)

    # --- Filtres Jinja utilitaires ---------------------------------------
    @app.template_filter("score_color")
    def score_color(score):
        """Retourne une classe CSS selon le score, pour un code couleur cohérent partout."""
        if score is None:
            return "score-neutral"
        if score >= 80:
            return "score-high"
        if score >= 50:
            return "score-medium"
        return "score-low"

    @app.template_filter("tel_href")
    def tel_href(phone):
        """
        Nettoie un numéro pour un lien `tel:` : on retire les espaces/tirets
        mais on garde le "+" international, que les navigateurs mobiles
        gèrent nativement pour composer un numéro directement.
        """
        if not phone:
            return ""
        return "".join(ch for ch in phone if ch.isdigit() or ch == "+")

    @app.template_filter("wa_number")
    def wa_number(phone):
        """
        Nettoie un numéro pour un lien `https://wa.me/<numero>` : WhatsApp
        exige uniquement des chiffres (indicatif pays inclus, sans "+").
        """
        if not phone:
            return ""
        return "".join(ch for ch in phone if ch.isdigit())

    # --- En-têtes de sécurité HTTP ----------------------------------------
    # Ajoutés à CHAQUE réponse, pages comme fichiers statiques. Ce sont des
    # protections "en profondeur" qui ne remplacent pas les bonnes pratiques
    # de code (échappement Jinja automatique, ORM, CSRF...) mais réduisent
    # l'impact d'une faille qui aurait échappé à ces protections.
    @app.after_request
    def set_security_headers(response):
        # Empêche le navigateur de "deviner" un type de fichier différent de
        # celui déclaré (protège contre certaines attaques XSS via upload).
        response.headers["X-Content-Type-Options"] = "nosniff"
        # Interdit d'afficher TrustHub dans une <iframe> d'un autre site
        # (anti-clickjacking : empêche de superposer un bouton invisible).
        response.headers["X-Frame-Options"] = "DENY"
        # Ne transmet jamais l'URL complète (avec ID de profil, etc.) comme
        # référent à un site externe.
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        # Politique de contenu : scripts uniquement depuis notre propre domaine
        # (aucun <script> inline n'est utilisé dans les templates, voir
        # static/js/main.js) ; 'unsafe-inline' n'est toléré que pour le CSS,
        # car de nombreux styles ponctuels sont encore en ligne dans les
        # templates (voir README, pistes d'amélioration).
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "object-src 'none'; "
            "base-uri 'self'; "
            "frame-ancestors 'none'"
        )
        if app.config.get("FORCE_HSTS"):
            # HSTS : force le navigateur à toujours utiliser HTTPS pour ce
            # domaine ensuite. À n'activer QUE si l'app est réellement servie
            # en HTTPS (ex: derrière ngrok) — voir README.
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        return response

    # --- Gestion des erreurs -------------------------------------------
    @app.errorhandler(403)
    def forbidden(_e):
        return render_template("error.html", code=403, message="Accès refusé."), 403

    @app.errorhandler(404)
    def not_found(_e):
        return render_template("error.html", code=404, message="Page introuvable."), 404

    @app.errorhandler(413)
    def too_large(_e):
        return render_template("error.html", code=413, message="Fichier trop volumineux (8 Mo max)."), 413

    @app.errorhandler(429)
    def rate_limited(_e):
        return render_template(
            "error.html", code=429, message="Trop de tentatives. Merci de réessayer dans quelques minutes."
        ), 429

    @app.errorhandler(500)
    def server_error(_e):
        # En production (debug=False), Flask n'affiche déjà aucune trace
        # technique par défaut ; ce handler garantit en plus une page cohérente
        # avec le reste du design plutôt que la page d'erreur brute de Flask.
        return render_template("error.html", code=500, message="Une erreur interne est survenue."), 500

    with app.app_context():
        db.create_all()

    return app


app = create_app()

if __name__ == "__main__":
    # SÉCURITÉ : le mode debug (débogueur interactif Werkzeug) permet
    # l'EXÉCUTION DE CODE ARBITRAIRE à quiconque atteint une page d'erreur.
    # Il ne doit JAMAIS être activé sur une app exposée publiquement (par
    # exemple via ngrok, voir README section PWA). Il reste désactivé par
    # défaut ici, et ne s'active que si la variable d'environnement
    # FLASK_DEBUG=true est explicitement définie pour du développement local.
    debug_mode = os.environ.get("FLASK_DEBUG", "false").lower() == "true"

    # host="0.0.0.0" est indispensable pour tester depuis un téléphone Android
    # sur le même réseau Wi-Fi que l'ordinateur (voir README, section PWA).
    app.run(host="0.0.0.0", port=5000, debug=debug_mode)
