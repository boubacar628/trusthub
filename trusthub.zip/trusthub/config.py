import os
import warnings

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

_DEFAULT_SECRET_KEY = "trusthub-dev-secret-key-a-changer"


class Config:
    """
    Configuration centrale de l'application.

    Pourquoi une classe Config séparée ?
    - Elle regroupe tous les réglages sensibles à un seul endroit.
    - Elle permet de basculer facilement vers PostgreSQL ou MySQL plus tard
      en changeant uniquement SQLALCHEMY_DATABASE_URI, sans toucher au reste
      du code (grâce à SQLAlchemy qui abstrait le moteur de base de données).
    """

    # Clé utilisée par Flask pour signer les sessions ET par Flask-WTF pour
    # générer les jetons CSRF (voir app.py -> CSRFProtect). EN PRODUCTION,
    # définissez SECRET_KEY dans l'environnement : une valeur par défaut
    # connue de tous (visible dans ce dépôt) ne protège plus rien.
    SECRET_KEY = os.environ.get("SECRET_KEY", _DEFAULT_SECRET_KEY)
    if SECRET_KEY == _DEFAULT_SECRET_KEY:
        warnings.warn(
            "SECURITE: SECRET_KEY par défaut utilisée (voir config.py). "
            "Définissez la variable d'environnement SECRET_KEY avant tout "
            "déploiement accessible publiquement (ex: via ngrok) — sans "
            "cela, les sessions et la protection CSRF peuvent être falsifiées.",
            stacklevel=2,
        )

    # Base de données SQLite : un simple fichier, parfait pour un MVP.
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'database', 'trusthub.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Dossier où seront stockées les preuves (photos, documents) uploadées.
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "pdf", "webp"}
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024  # 8 Mo max par fichier uploadé (sécurité anti-abus)

    # --- Sécurité des cookies de session ---------------------------------
    SESSION_COOKIE_HTTPONLY = True   # inaccessible en JavaScript (anti-vol par XSS)
    SESSION_COOKIE_SAMESITE = "Lax"  # bloque l'envoi du cookie depuis un site tiers (anti-CSRF en profondeur)
    # SESSION_COOKIE_SECURE : le cookie ne doit être envoyé qu'en HTTPS. Désactivé
    # par défaut pour ne pas casser les tests en HTTP local (voir README, test
    # sur Wi-Fi), mais DOIT être activé dès que l'app est servie en HTTPS
    # (ex: derrière ngrok) via la variable d'environnement FORCE_SECURE_COOKIES=true.
    SESSION_COOKIE_SECURE = os.environ.get("FORCE_SECURE_COOKIES", "false").lower() == "true"
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 7  # 7 jours

    # --- CSRF (Flask-WTF) --------------------------------------------------
    WTF_CSRF_TIME_LIMIT = None  # un jeton ne périme pas en cours de session (évite des erreurs sur formulaires ouverts longtemps)
