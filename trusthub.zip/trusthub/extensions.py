from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# Ces objets sont créés ICI, sans être attachés à une app Flask tout de suite.
# C'est le pattern "Application Factory" : on les initialise réellement dans app.py
# avec db.init_app(app). Cela évite les imports circulaires entre app.py, models.py
# et les blueprints de routes/, qui ont tous besoin d'accéder à "db" ou "login_manager".
db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "Veuillez vous connecter pour accéder à cette page."
login_manager.login_message_category = "info"

# CSRFProtect protège TOUS les formulaires POST/PUT/DELETE de l'application :
# chaque formulaire doit inclure {{ csrf_token() }} (voir templates), sans quoi
# la requête est rejetée. Cela empêche un site malveillant de soumettre des
# actions (changer un mot de passe, valider une preuve...) au nom d'un
# utilisateur connecté à son insu.
csrf = CSRFProtect()

# Limite le nombre de requêtes par adresse IP sur les routes sensibles
# (connexion, inscription) pour ralentir une attaque par force brute sur les
# mots de passe. En mémoire par défaut : suffisant pour un MVP mono-serveur,
# mais à remplacer par un backend Redis partagé si l'app tourne un jour sur
# plusieurs processus/serveurs (voir Flask-Limiter docs : storage_uri).
limiter = Limiter(key_func=get_remote_address)
