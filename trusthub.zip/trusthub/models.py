from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db

# ---------------------------------------------------------------------------
# Pourquoi ce découpage en modèles ?
#
# Chaque table représente UNE responsabilité claire :
#   User               -> qui se connecte (client, professionnel ou admin)
#   ProfessionalProfile-> la fiche "métier" d'un professionnel
#   Category           -> les domaines d'activité (maçon, développeur, ...)
#   Skill              -> les compétences déclarées par un professionnel
#   Evidence           -> les preuves (photos, documents, certifications...)
#   Project            -> une prestation demandée par un client (la "transaction")
#   Review             -> l'évaluation laissée après une prestation confirmée
#   TrustScore         -> le score de confiance calculé et mis en cache
#   Favorite           -> les professionnels qu'un client a mis en favoris
#
# Séparer TrustScore de ProfessionalProfile permet de recalculer le score
# à partir des Review sans jamais toucher aux informations du profil lui-même.
# ---------------------------------------------------------------------------


class User(UserMixin, db.Model):
    """
    Représente un compte. Le champ `role` détermine le comportement de
    l'utilisateur dans toute l'application (client / professionnel / admin).
    Flask-Login a besoin d'un id, ce que UserMixin fournit automatiquement
    à partir de la clé primaire `id`.
    """

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="client")  # client | professional | admin
    phone = db.Column(db.String(30))
    # Optionnel : si vide, le bouton WhatsApp du profil utilise `phone`.
    # Séparé de `phone` car certains professionnels utilisent un numéro
    # WhatsApp Business différent de leur ligne d'appel classique.
    whatsapp = db.Column(db.String(30))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active_account = db.Column(db.Boolean, default=True)

    professional_profile = db.relationship(
        "ProfessionalProfile", backref="user", uselist=False, cascade="all, delete-orphan"
    )
    projects_as_client = db.relationship(
        "Project", foreign_keys="Project.client_id", backref="client", lazy="dynamic"
    )
    favorites = db.relationship("Favorite", backref="client", lazy="dynamic", cascade="all, delete-orphan")

    def set_password(self, raw_password):
        # Le mot de passe n'est jamais stocké en clair : uniquement son empreinte (hash).
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    def is_admin(self):
        return self.role == "admin"

    def is_professional(self):
        return self.role == "professional"

    def __repr__(self):
        return f"<User {self.email} ({self.role})>"


class Category(db.Model):
    """
    Domaine d'activité : Maçon, Électricien, Vendeur de matériaux, Professeur, etc.

    TrustHub ne se limite pas au bâtiment : le champ `sector` regroupe les
    catégories par grand secteur (Bâtiment, Commerce, Éducation, Santé...) pour
    que la plateforme reste lisible même avec des dizaines de métiers différents,
    et pour que la recherche/l'accueil puissent proposer un premier tri par
    secteur avant de choisir un métier précis.
    """

    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    icon = db.Column(db.String(10), default="🔧")  # emoji simple pour l'UI mobile, sans dépendance externe
    sector = db.Column(db.String(100), nullable=False, default="Autre", index=True)

    # TrustHub prouve la confiance différemment selon ce qu'on évalue :
    # - "prestataire" (maçon, développeur, professeur...) : on évalue un TRAVAIL.
    # - "vendeur" (boutique, revendeur de matériaux...) : on évalue un PRODUIT.
    # Ce champ pilote quels critères d'avis sont proposés (voir Review et
    # utils.recalculate_trust_score) et donc comment le score de confiance
    # de 87/100 est réellement composé pour ce métier.
    category_type = db.Column(db.String(20), nullable=False, default="prestataire")  # prestataire | vendeur

    professionals = db.relationship("ProfessionalProfile", backref="category", lazy="dynamic")


class ProfessionalProfile(db.Model):
    """
    La fiche "confiance" d'un professionnel. C'est la pièce centrale de TrustHub :
    c'est elle que les clients consultent avant de faire appel à quelqu'un.

    Le champ `status` matérialise la progression de la confiance :
      non_verifie -> verifie -> recommande
    Cette progression est décrite en détail dans le README.
    """

    __tablename__ = "professional_profiles"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)

    location = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    years_experience = db.Column(db.Integer, default=0)
    photo_filename = db.Column(db.String(255), default="default_avatar.png")

    status = db.Column(db.String(20), default="non_verifie")  # non_verifie | verifie | recommande
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Signalement grave : au moins un client a déclaré que ce prestataire a
    # disparu (ou n'a pas terminé correctement) après avoir été payé. Tant que
    # ce drapeau est actif, le statut retombe automatiquement à "non_verifie"
    # (voir utils.update_verification_status) et le profil affiche un
    # avertissement visible, jusqu'à ce qu'un administrateur l'examine et le
    # lève depuis /admin.
    payment_complaint_flag = db.Column(db.Boolean, default=False, nullable=False)
    # Quand un administrateur lève un signalement après vérification, on ne
    # veut pas que l'ancien avis négatif "ressuscite" le drapeau à chaque
    # recalcul futur : seuls les avis postérieurs à cette date comptent pour
    # ré-évaluer le critère fiabilité-paiement (voir utils.recalculate_trust_score).
    payment_complaint_cleared_at = db.Column(db.DateTime, nullable=True)

    skills = db.relationship("Skill", backref="professional", lazy="dynamic", cascade="all, delete-orphan")
    evidences = db.relationship("Evidence", backref="professional", lazy="dynamic", cascade="all, delete-orphan")
    projects = db.relationship("Project", backref="professional", lazy="dynamic", cascade="all, delete-orphan")
    trust_score = db.relationship(
        "TrustScore", backref="professional", uselist=False, cascade="all, delete-orphan"
    )

    def verified_evidence_count(self):
        return self.evidences.filter_by(status="acceptee").count()

    def completed_projects_count(self):
        # Une prestation est "réalisée" dès que le client l'a confirmée,
        # qu'un avis ait déjà été laissé ensuite ou non.
        return self.projects.filter(Project.status.in_(["confirmee", "avis_laisse"])).count()

    def global_score(self):
        return self.trust_score.global_score if self.trust_score else 0

    def is_vendor(self):
        """True si ce profil vend des produits plutôt qu'il ne rend un service."""
        return self.category.category_type == "vendeur"


class Skill(db.Model):
    __tablename__ = "skills"

    id = db.Column(db.Integer, primary_key=True)
    professional_id = db.Column(db.Integer, db.ForeignKey("professional_profiles.id"), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    level = db.Column(db.String(20), default="intermediaire")  # debutant | intermediaire | avance | expert


class Evidence(db.Model):
    """
    Une preuve soumise par un professionnel : photo de réalisation, document,
    certification, témoignage... Chaque preuve doit être validée par un admin
    avant de compter dans le score de confiance.
    """

    __tablename__ = "evidences"

    id = db.Column(db.Integer, primary_key=True)
    professional_id = db.Column(db.Integer, db.ForeignKey("professional_profiles.id"), nullable=False)

    evidence_type = db.Column(db.String(30), nullable=False)  # photo | document | certification | temoignage
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    filename = db.Column(db.String(255))  # nom du fichier dans static/uploads

    status = db.Column(db.String(20), default="en_attente")  # en_attente | acceptee | refusee
    admin_comment = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime)


class Project(db.Model):
    """
    Représente une prestation, du premier contact jusqu'à l'avis final.
    C'est la "transaction" qui garantit qu'un avis correspond à un vrai travail :
    on ne peut pas laisser d'avis sans être passé par ce cycle complet.

    Cycle de vie du champ `status` :
      demandee -> acceptee | refusee
      acceptee -> confirmee   (le client confirme que le travail a été fait)
      confirmee -> avis_laisse (une Review a été créée)
    """

    __tablename__ = "projects"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    professional_id = db.Column(db.Integer, db.ForeignKey("professional_profiles.id"), nullable=False)

    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default="demandee")
    # demandee | acceptee | refusee | confirmee | avis_laisse

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    accepted_at = db.Column(db.DateTime)
    confirmed_at = db.Column(db.DateTime)

    review = db.relationship("Review", backref="project", uselist=False, cascade="all, delete-orphan")


class Review(db.Model):
    """
    Une évaluation, toujours liée à un Project confirmé — jamais laissée "à vide".

    Les critères ne sont PAS les mêmes selon ce qui est évalué
    (voir Category.category_type) :

    - Prestataire (maçon, développeur, professeur...) : on prouve la valeur
      d'un TRAVAIL. Trois critères :
        * qualite            -> qualité du travail réalisé (1 à 5)
        * respect_delais      -> le délai promis a-t-il été respecté ? (1 à 5)
        * fiabilite_paiement   -> LE critère de confiance le plus important :
          une fois payé, le prestataire a-t-il bien terminé le travail
          correctement, sans disparaître ? (True/False, pas une simple note :
          c'est un signal factuel, pas une opinion). Une seule réponse "Non"
          déclenche un signalement grave (voir ProfessionalProfile.payment_complaint_flag).

    - Vendeur (boutique, revendeur de matériaux...) : on prouve la valeur
      d'un PRODUIT. Deux critères :
        * qualite         -> qualité du produit vendu (1 à 5)
        * prix_abordable    -> le prix était-il raisonnable pour ce qui a été
          reçu ? (1 à 5)

    Chaque avis ne remplit que les champs pertinents pour le type de profil
    concerné ; les autres restent `None` (voir routes/professionals.py ->
    leave_review, qui construit le bon formulaire selon Category.category_type).
    """

    __tablename__ = "reviews"

    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey("projects.id"), nullable=False, unique=True)

    qualite = db.Column(db.Integer, nullable=False)  # 1 à 5 — qualité du travail OU du produit

    # --- Critères "prestataire" uniquement ---
    respect_delais = db.Column(db.Integer, nullable=True)       # 1 à 5
    fiabilite_paiement = db.Column(db.Boolean, nullable=True)   # True = a bien terminé après paiement

    # --- Critère "vendeur" uniquement ---
    prix_abordable = db.Column(db.Integer, nullable=True)        # 1 à 5

    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class TrustScore(db.Model):
    """
    Cache du score de confiance d'un professionnel, recalculé à chaque nouvel avis
    ou nouvelle preuve validée (voir utils.recalculate_trust_score). On le stocke
    plutôt que de le recalculer à chaque affichage, car la page de recherche doit
    trier des dizaines de profils rapidement (voir routes/professionals.py -> search()).

    Les colonnes ne sont pas toutes utilisées pour tout le monde : un vendeur
    n'a pas de `delais_pct` ni de `fiabilite_paiement_pct` (non pertinents pour
    un produit), un prestataire n'a pas de `prix_pct`. Voir Category.category_type.
    """

    __tablename__ = "trust_scores"

    id = db.Column(db.Integer, primary_key=True)
    professional_id = db.Column(
        db.Integer, db.ForeignKey("professional_profiles.id"), nullable=False, unique=True
    )

    qualite_pct = db.Column(db.Float, default=0)                   # qualité du travail / du produit
    delais_pct = db.Column(db.Float, nullable=True)                 # prestataire uniquement
    fiabilite_paiement_pct = db.Column(db.Float, nullable=True)      # prestataire uniquement (% de "a bien terminé")
    prix_pct = db.Column(db.Float, nullable=True)                    # vendeur uniquement
    global_score = db.Column(db.Float, default=0)  # sur 100

    updated_at = db.Column(db.DateTime, default=datetime.utcnow)


class Favorite(db.Model):
    """Permet à un client de sauvegarder un professionnel pour le retrouver facilement."""

    __tablename__ = "favorites"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    professional_id = db.Column(db.Integer, db.ForeignKey("professional_profiles.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    professional = db.relationship("ProfessionalProfile")

    __table_args__ = (db.UniqueConstraint("client_id", "professional_id", name="uq_favorite"),)
