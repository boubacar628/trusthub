# Ce fichier rend le dossier "routes" importable comme un package Python.
# Chaque fichier du dossier (auth.py, users.py, professionals.py, admin.py, main.py)
# définit un Blueprint Flask, enregistré ensuite dans app.py.
# Ce découpage évite un unique fichier routes.py de plusieurs centaines de lignes
# et permet à plusieurs développeurs de travailler sur des zones différentes
# de l'application sans conflit.
