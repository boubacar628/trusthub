from datetime import datetime
from functools import wraps

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user

from extensions import db
from models import Evidence, ProfessionalProfile, User, Category
from utils import recalculate_trust_score, update_verification_status

admin_bp = Blueprint("admin", __name__)


def admin_required(view_func):
    """
    Petit décorateur maison : plutôt que de répéter `if not current_user.is_admin(): abort(403)`
    dans chaque route de ce fichier, on centralise la vérification ici.
    """

    @wraps(view_func)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            abort(403)
        return view_func(*args, **kwargs)

    return wrapper


@admin_bp.route("/admin")
@login_required
@admin_required
def dashboard():
    pending_evidences = Evidence.query.filter_by(status="en_attente").order_by(Evidence.created_at).all()
    professionals = ProfessionalProfile.query.all()
    flagged_professionals = ProfessionalProfile.query.filter_by(payment_complaint_flag=True).all()
    total_users = User.query.count()

    return render_template(
        "admin_dashboard.html",
        pending_evidences=pending_evidences,
        professionals=professionals,
        flagged_professionals=flagged_professionals,
        total_users=total_users,
    )


@admin_bp.route("/admin/evidence/<int:evidence_id>/validate", methods=["POST"])
@login_required
@admin_required
def validate_evidence(evidence_id):
    evidence = Evidence.query.get_or_404(evidence_id)
    evidence.status = "acceptee"
    evidence.reviewed_at = datetime.utcnow()
    db.session.commit()

    # Valider une preuve peut faire passer un professionnel de
    # "non_verifie" à "verifie" : on recalcule donc son statut immédiatement.
    update_verification_status(evidence.professional)
    db.session.commit()

    flash("Preuve validée.", "success")
    return redirect(url_for("admin.dashboard"))


@admin_bp.route("/admin/evidence/<int:evidence_id>/refuse", methods=["POST"])
@login_required
@admin_required
def refuse_evidence(evidence_id):
    evidence = Evidence.query.get_or_404(evidence_id)
    evidence.status = "refusee"
    evidence.admin_comment = request.form.get("comment", "").strip()
    evidence.reviewed_at = datetime.utcnow()
    db.session.commit()

    flash("Preuve refusée.", "info")
    return redirect(url_for("admin.dashboard"))


# ---------------------------------------------------------------------------
# SIGNALEMENTS DE PAIEMENT
#
# C'est le garde-fou le plus important de TrustHub pour les prestataires :
# un client a déclaré qu'un professionnel a disparu (ou n'a pas terminé
# correctement) après avoir été payé. Le profil repasse automatiquement en
# "non_verifie" et son score est plafonné (voir utils.recalculate_trust_score)
# tant qu'un administrateur n'a pas examiné la situation et, le cas échéant,
# levé le signalement ici.
# ---------------------------------------------------------------------------

@admin_bp.route("/admin/professional/<int:profile_id>/clear-complaint", methods=["POST"])
@login_required
@admin_required
def clear_payment_complaint(profile_id):
    profile = ProfessionalProfile.query.get_or_404(profile_id)
    profile.payment_complaint_cleared_at = datetime.utcnow()
    db.session.commit()

    recalculate_trust_score(profile)  # recalcule le score/statut sans l'ancien signalement
    flash("Signalement levé après vérification. Le profil peut de nouveau progresser normalement.", "success")
    return redirect(url_for("admin.dashboard"))


# ---------------------------------------------------------------------------
# GESTION DES SECTEURS / MÉTIERS
#
# TrustHub doit couvrir "tous les secteurs où les gens ont besoin de faire
# confiance" (bâtiment, commerce, éducation, vente de produits...). Plutôt que
# de figer la liste des métiers dans le code, l'administrateur peut en ajouter
# de nouveaux à tout moment depuis cette page, sans redéploiement.
# ---------------------------------------------------------------------------

@admin_bp.route("/admin/categories")
@login_required
@admin_required
def categories():
    all_categories = Category.query.order_by(Category.sector, Category.name).all()
    sectors = sorted({c.sector for c in all_categories})
    return render_template("admin_categories.html", categories=all_categories, sectors=sectors)


@admin_bp.route("/admin/categories/add", methods=["POST"])
@login_required
@admin_required
def add_category():
    name = request.form.get("name", "").strip()
    icon = request.form.get("icon", "").strip() or "🔧"
    sector = request.form.get("sector", "").strip()
    category_type = request.form.get("category_type", "prestataire")
    if category_type not in ("prestataire", "vendeur"):
        category_type = "prestataire"
    # Permet de choisir un secteur existant OU d'en taper un nouveau
    # (le champ texte "new_sector" a priorité s'il est rempli).
    new_sector = request.form.get("new_sector", "").strip()
    if new_sector:
        sector = new_sector

    if not name or not sector:
        flash("Le nom du métier et le secteur sont obligatoires.", "error")
        return redirect(url_for("admin.categories"))

    if Category.query.filter_by(name=name).first():
        flash("Ce métier existe déjà.", "error")
        return redirect(url_for("admin.categories"))

    db.session.add(Category(name=name, icon=icon, sector=sector, category_type=category_type))
    db.session.commit()
    flash(f"Métier « {name} » ajouté au secteur « {sector} ».", "success")
    return redirect(url_for("admin.categories"))


@admin_bp.route("/admin/categories/<int:category_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_category(category_id):
    category = Category.query.get_or_404(category_id)
    if category.professionals.count() > 0:
        flash("Impossible de supprimer un métier utilisé par des professionnels.", "error")
        return redirect(url_for("admin.categories"))

    db.session.delete(category)
    db.session.commit()
    flash("Métier supprimé.", "info")
    return redirect(url_for("admin.categories"))
