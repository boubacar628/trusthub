import re

from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, login_required, current_user

from extensions import db, limiter
from models import User

auth_bp = Blueprint("auth", __name__)

# Format email volontairement simple (pas de RFC 5322 complet) : suffisant
# pour rejeter les saisies clairement invalides sans bloquer de vrais emails.
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@auth_bp.route("/register", methods=["GET", "POST"])
@limiter.limit("10 per hour")  # anti-abus : limite la création massive de comptes depuis une même IP
def register():
    """
    Inscription. Le champ `role` détermine si le compte est un Client
    ou un Professionnel. Un compte Admin ne peut PAS être créé ici :
    il est créé uniquement via seed.py, pour éviter que n'importe qui
    s'auto-promeuve administrateur.
    """
    if current_user.is_authenticated:
        return redirect(url_for("users.dashboard"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "client")

        if role not in ("client", "professional"):
            role = "client"

        if not name or not email or not password:
            flash("Merci de remplir tous les champs.", "error")
            return render_template("register.html")

        if not EMAIL_RE.match(email):
            flash("Merci de saisir une adresse email valide.", "error")
            return render_template("register.html")

        if len(password) < 6:
            flash("Le mot de passe doit contenir au moins 6 caractères.", "error")
            return render_template("register.html")

        if User.query.filter_by(email=email).first():
            flash("Un compte existe déjà avec cet email.", "error")
            return render_template("register.html")

        user = User(name=name, email=email, role=role)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        session.clear()  # repart d'une session neuve avant l'authentification (défense en profondeur)
        login_user(user)
        flash("Bienvenue sur TrustHub !", "success")

        if role == "professional":
            # On envoie directement le professionnel compléter sa fiche :
            # un compte professionnel "vide" n'a aucune valeur pour les clients.
            return redirect(url_for("professionals.setup_profile"))
        return redirect(url_for("users.dashboard"))

    return render_template("register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per minute")  # ralentit une attaque par force brute sur les mots de passe
def login():
    if current_user.is_authenticated:
        return redirect(url_for("users.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = User.query.filter_by(email=email).first()

        # On renvoie volontairement le même message que l'email existe ou non :
        # cela évite qu'un attaquant devine quels emails sont inscrits sur TrustHub.
        if not user or not user.check_password(password):
            flash("Email ou mot de passe incorrect.", "error")
            return render_template("login.html")

        session.clear()  # repart d'une session neuve avant l'authentification (défense en profondeur)
        login_user(user)
        flash(f"Content de vous revoir, {user.name} !", "success")

        if user.is_admin():
            return redirect(url_for("admin.dashboard"))
        return redirect(url_for("users.dashboard"))

    return render_template("login.html")


@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    session.clear()
    flash("Vous avez été déconnecté.", "info")
    return redirect(url_for("main.index"))
