from flask import Blueprint, render_template, current_app, send_from_directory

from models import Category, ProfessionalProfile, TrustScore

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """
    Page d'accueil : met en avant quelques catégories et les professionnels
    les mieux notés, pour donner tout de suite une preuve de concept du
    concept central de TrustHub ("la confiance se prouve").
    """
    categories = Category.query.order_by(Category.sector, Category.name).all()
    # L'accueil affiche les grands SECTEURS (Bâtiment, Commerce, Éducation...)
    # plutôt que chaque métier un par un : avec des dizaines de catégories
    # possibles, une grille de secteurs reste lisible sur un écran de téléphone.
    sectors = sorted({c.sector for c in categories})
    top_professionals = (
        ProfessionalProfile.query.join(TrustScore)
        .order_by(TrustScore.global_score.desc())
        .limit(3)
        .all()
    )
    return render_template("index.html", sectors=sectors, top_professionals=top_professionals)


@main_bp.route("/offline")
def offline():
    """
    Page affichée par le service worker quand il n'y a ni réseau ni version
    en cache d'une page demandée. Volontairement minimaliste et sans requête
    à la base de données : elle doit pouvoir s'afficher même hors-ligne.
    """
    return render_template("offline.html")


@main_bp.route("/sw.js")
def service_worker():
    """
    Sert le service worker DEPUIS LA RACINE (/sw.js) plutôt que /static/sw.js.
    C'est indispensable : la portée ("scope") par défaut d'un service worker
    est le dossier dans lequel il est servi. Si on le laissait sous /static/,
    il ne pourrait contrôler que les fichiers statiques, jamais les pages
    HTML de l'application (/, /search, /dashboard...).
    """
    response = send_from_directory(current_app.static_folder, "sw.js")
    response.headers["Content-Type"] = "application/javascript"
    return response
