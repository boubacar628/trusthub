from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user

from extensions import db
from models import (
    ProfessionalProfile,
    Category,
    Skill,
    Evidence,
    Project,
    Review,
    TrustScore,
    Favorite,
)
from utils import save_uploaded_file, recalculate_trust_score

professionals_bp = Blueprint("professionals", __name__)


# ---------------------------------------------------------------------------
# RECHERCHE
# ---------------------------------------------------------------------------

@professionals_bp.route("/search")
def search():
    """
    Coeur du "moteur de confiance" : on ne trie jamais par ancienneté du compte
    ou par popularité, mais par score de confiance décroissant, puis par
    nombre de preuves validées. C'est ce qui matérialise la promesse de
    TrustHub : la position dans les résultats se mérite avec des preuves.
    """
    category_id = request.args.get("category", type=int)
    sector = request.args.get("sector", "").strip()
    location = request.args.get("location", "").strip()
    min_score = request.args.get("min_score", type=int, default=0)

    query = ProfessionalProfile.query.outerjoin(TrustScore)

    if category_id:
        query = query.filter(ProfessionalProfile.category_id == category_id)
    if sector:
        query = query.join(Category).filter(Category.sector == sector)
    if location:
        query = query.filter(ProfessionalProfile.location.ilike(f"%{location}%"))
    if min_score:
        query = query.filter(TrustScore.global_score >= min_score)

    professionals = query.order_by(TrustScore.global_score.desc().nullslast()).all()

    # Les catégories sont groupées par secteur pour rester lisibles dans le
    # <select> même avec des dizaines de métiers différents (voir template).
    categories = Category.query.order_by(Category.sector, Category.name).all()
    sectors = sorted({c.sector for c in categories})

    return render_template(
        "search.html",
        professionals=professionals,
        categories=categories,
        sectors=sectors,
        selected_category=category_id,
        selected_sector=sector,
        location=location,
        min_score=min_score,
    )


# ---------------------------------------------------------------------------
# PROFIL PROFESSIONNEL (vue publique)
# ---------------------------------------------------------------------------

@professionals_bp.route("/professional/<int:profile_id>")
def view_profile(profile_id):
    profile = ProfessionalProfile.query.get_or_404(profile_id)
    is_favorite = False
    if current_user.is_authenticated and current_user.role == "client":
        is_favorite = (
            Favorite.query.filter_by(client_id=current_user.id, professional_id=profile.id).first()
            is not None
        )
    accepted_evidences = profile.evidences.filter_by(status="acceptee").all()
    return render_template("professional_profile.html", profile=profile, is_favorite=is_favorite,
                            evidences=accepted_evidences)


# ---------------------------------------------------------------------------
# CRÉATION / ÉDITION DE LA FICHE PROFESSIONNELLE
# ---------------------------------------------------------------------------

@professionals_bp.route("/professional/setup", methods=["GET", "POST"])
@login_required
def setup_profile():
    if current_user.role != "professional":
        abort(403)

    profile = current_user.professional_profile
    categories = Category.query.order_by(Category.sector, Category.name).all()

    if request.method == "POST":
        category_id = request.form.get("category_id", type=int)
        location = request.form.get("location", "").strip()
        description = request.form.get("description", "").strip()
        years_experience = request.form.get("years_experience", type=int, default=0)
        phone = request.form.get("phone", "").strip()
        whatsapp = request.form.get("whatsapp", "").strip()

        if not category_id or not location:
            flash("Le domaine et la localisation sont obligatoires.", "error")
            return render_template("professional_setup.html", profile=profile, categories=categories)

        # Le téléphone est désormais OBLIGATOIRE : c'est par cet appel, ou par
        # WhatsApp/email, que les clients contactent directement un professionnel
        # (voir professional_profile.html, section "Contacter"). Sans numéro,
        # le profil n'a aucun moyen de contact réel pour un client.
        if not phone:
            flash("Un numéro de téléphone est obligatoire pour que les clients puissent vous contacter.", "error")
            return render_template("professional_setup.html", profile=profile, categories=categories)

        if profile is None:
            profile = ProfessionalProfile(user_id=current_user.id)
            db.session.add(profile)

        profile.category_id = category_id
        profile.location = location
        profile.description = description
        profile.years_experience = years_experience or 0

        current_user.phone = phone
        current_user.whatsapp = whatsapp or None  # vide -> le profil utilisera `phone` pour WhatsApp

        db.session.commit()
        flash("Votre fiche professionnelle a été enregistrée.", "success")
        return redirect(url_for("users.dashboard"))

    return render_template("professional_setup.html", profile=profile, categories=categories)


@professionals_bp.route("/professional/skills/add", methods=["POST"])
@login_required
def add_skill():
    if current_user.role != "professional" or not current_user.professional_profile:
        abort(403)

    name = request.form.get("name", "").strip()
    level = request.form.get("level", "intermediaire")

    if name:
        skill = Skill(professional_id=current_user.professional_profile.id, name=name, level=level)
        db.session.add(skill)
        db.session.commit()
        flash("Compétence ajoutée.", "success")

    return redirect(url_for("users.dashboard"))


# ---------------------------------------------------------------------------
# PREUVES
# ---------------------------------------------------------------------------

@professionals_bp.route("/professional/evidence/add", methods=["GET", "POST"])
@login_required
def add_evidence():
    if current_user.role != "professional" or not current_user.professional_profile:
        flash("Créez d'abord votre fiche professionnelle.", "error")
        return redirect(url_for("professionals.setup_profile"))

    if request.method == "POST":
        evidence_type = request.form.get("evidence_type", "photo")
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        file = request.files.get("file")

        if not title:
            flash("Le titre de la preuve est obligatoire.", "error")
            return render_template("add_evidence.html")

        try:
            filename = save_uploaded_file(file)
        except ValueError as exc:
            flash(str(exc), "error")
            return render_template("add_evidence.html")

        evidence = Evidence(
            professional_id=current_user.professional_profile.id,
            evidence_type=evidence_type,
            title=title,
            description=description,
            filename=filename,
            status="en_attente",
        )
        db.session.add(evidence)
        db.session.commit()
        flash("Preuve envoyée. Elle sera examinée par un administrateur.", "success")
        return redirect(url_for("users.dashboard"))

    return render_template("add_evidence.html")


# ---------------------------------------------------------------------------
# FAVORIS
# ---------------------------------------------------------------------------

@professionals_bp.route("/professional/<int:profile_id>/favorite", methods=["POST"])
@login_required
def toggle_favorite(profile_id):
    if current_user.role != "client":
        abort(403)

    existing = Favorite.query.filter_by(client_id=current_user.id, professional_id=profile_id).first()
    if existing:
        db.session.delete(existing)
        flash("Retiré de vos favoris.", "info")
    else:
        db.session.add(Favorite(client_id=current_user.id, professional_id=profile_id))
        flash("Ajouté à vos favoris.", "success")

    db.session.commit()
    return redirect(url_for("professionals.view_profile", profile_id=profile_id))


# ---------------------------------------------------------------------------
# CYCLE DE VIE D'UNE PRESTATION (Project)
# ---------------------------------------------------------------------------

@professionals_bp.route("/professional/<int:profile_id>/request", methods=["POST"])
@login_required
def request_project(profile_id):
    """
    Un client envoie une demande de prestation. C'est le point de départ
    obligatoire du cycle : aucun avis ne pourra exister sans passer par ici.
    """
    if current_user.role != "client":
        abort(403)

    profile = ProfessionalProfile.query.get_or_404(profile_id)
    description = request.form.get("description", "").strip()

    if not description:
        flash("Merci de décrire votre besoin.", "error")
        return redirect(url_for("professionals.view_profile", profile_id=profile_id))

    project = Project(client_id=current_user.id, professional_id=profile.id, description=description)
    db.session.add(project)
    db.session.commit()
    flash("Votre demande a été envoyée au professionnel.", "success")
    return redirect(url_for("professionals.view_profile", profile_id=profile_id))


@professionals_bp.route("/project/<int:project_id>/accept", methods=["POST"])
@login_required
def accept_project(project_id):
    project = Project.query.get_or_404(project_id)
    _ensure_owner_professional(project)

    project.status = "acceptee"
    project.accepted_at = datetime.utcnow()
    db.session.commit()
    flash("Demande acceptée.", "success")
    return redirect(url_for("users.dashboard"))


@professionals_bp.route("/project/<int:project_id>/refuse", methods=["POST"])
@login_required
def refuse_project(project_id):
    project = Project.query.get_or_404(project_id)
    _ensure_owner_professional(project)

    project.status = "refusee"
    db.session.commit()
    flash("Demande refusée.", "info")
    return redirect(url_for("users.dashboard"))


@professionals_bp.route("/project/<int:project_id>/confirm", methods=["POST"])
@login_required
def confirm_project(project_id):
    """
    Seul le CLIENT peut confirmer qu'un travail a réellement été effectué.
    C'est cette confirmation, et uniquement elle, qui débloque le droit
    de laisser un avis (voir leave_review). Cela garantit que le score
    de confiance ne peut pas être manipulé par de faux avis.
    """
    project = Project.query.get_or_404(project_id)
    if project.client_id != current_user.id:
        abort(403)
    if project.status != "acceptee":
        flash("Cette prestation ne peut pas encore être confirmée.", "error")
        return redirect(url_for("users.dashboard"))

    project.status = "confirmee"
    project.confirmed_at = datetime.utcnow()
    db.session.commit()

    recalculate_trust_score(project.professional)
    flash("Travail confirmé. Vous pouvez maintenant laisser un avis.", "success")
    return redirect(url_for("professionals.leave_review", project_id=project.id))


@professionals_bp.route("/project/<int:project_id>/review", methods=["GET", "POST"])
@login_required
def leave_review(project_id):
    project = Project.query.get_or_404(project_id)
    if project.client_id != current_user.id:
        abort(403)
    if project.status not in ("confirmee",):
        flash("Un avis ne peut être laissé qu'après confirmation du travail.", "error")
        return redirect(url_for("users.dashboard"))
    if project.review is not None:
        flash("Vous avez déjà laissé un avis pour cette prestation.", "info")
        return redirect(url_for("users.dashboard"))

    is_vendor = project.professional.is_vendor()

    if request.method == "POST":
        def _rating(field):
            value = request.form.get(field, type=int, default=3)
            return max(1, min(5, value))

        if is_vendor:
            review = Review(
                project_id=project.id,
                qualite=_rating("qualite"),
                prix_abordable=_rating("prix_abordable"),
                comment=request.form.get("comment", "").strip(),
            )
        else:
            # fiabilite_paiement n'est PAS une note : c'est une déclaration
            # factuelle du client ("oui" ou "non"), volontairement plus grave
            # qu'un simple 1-5, car un "non" ici signale un possible abus
            # (voir utils.recalculate_trust_score et le signalement admin).
            fiabilite_paiement = request.form.get("fiabilite_paiement") == "oui"
            review = Review(
                project_id=project.id,
                qualite=_rating("qualite"),
                respect_delais=_rating("respect_delais"),
                fiabilite_paiement=fiabilite_paiement,
                comment=request.form.get("comment", "").strip(),
            )

        db.session.add(review)
        project.status = "avis_laisse"
        db.session.commit()

        recalculate_trust_score(project.professional)

        if not is_vendor and not fiabilite_paiement:
            flash(
                "Votre signalement a été enregistré. Comme il concerne le paiement, "
                "un administrateur va examiner ce profil : merci pour votre vigilance.",
                "error",
            )
        else:
            flash("Merci pour votre avis, il met à jour le score de confiance !", "success")
        return redirect(url_for("users.dashboard"))

    return render_template("leave_review.html", project=project, is_vendor=is_vendor)


def _ensure_owner_professional(project):
    if (
        not current_user.professional_profile
        or project.professional_id != current_user.professional_profile.id
    ):
        abort(403)
