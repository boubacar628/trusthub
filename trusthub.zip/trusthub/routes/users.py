from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user

from models import Project, Favorite

users_bp = Blueprint("users", __name__)


@users_bp.route("/dashboard")
@login_required
def dashboard():
    """Redirige vers le bon tableau de bord selon le rôle du compte connecté."""
    if current_user.is_admin():
        return redirect(url_for("admin.dashboard"))
    if current_user.is_professional():
        return redirect(url_for("users.dashboard_professional"))
    return redirect(url_for("users.dashboard_client"))


@users_bp.route("/dashboard/client")
@login_required
def dashboard_client():
    if current_user.role != "client":
        return redirect(url_for("users.dashboard"))

    my_projects = current_user.projects_as_client.order_by(Project.created_at.desc()).all()
    favorites = Favorite.query.filter_by(client_id=current_user.id).all()

    return render_template("dashboard_client.html", projects=my_projects, favorites=favorites)


@users_bp.route("/dashboard/professional")
@login_required
def dashboard_professional():
    if current_user.role != "professional":
        return redirect(url_for("users.dashboard"))

    profile = current_user.professional_profile
    if profile is None:
        return redirect(url_for("professionals.setup_profile"))

    pending_requests = profile.projects.filter_by(status="demandee").all()
    active_projects = profile.projects.filter_by(status="acceptee").all()
    history = profile.projects.filter(Project.status.in_(["confirmee", "avis_laisse", "refusee"])).all()

    return render_template(
        "dashboard_professional.html",
        profile=profile,
        pending_requests=pending_requests,
        active_projects=active_projects,
        history=history,
    )
