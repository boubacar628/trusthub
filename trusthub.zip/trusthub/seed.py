"""
seed.py — Génère des données de démonstration pour TrustHub.

Pourquoi un script séparé plutôt que de créer ces données dans app.py ?
- On ne veut JAMAIS recréer ces données à chaque démarrage du serveur
  (sinon impossible de tester la création de vrais comptes durablement).
- Cela isole clairement "données de démo" et "code de l'application".
- C'est aussi ici, et seulement ici, qu'un compte admin est créé :
  voir routes/auth.py qui interdit volontairement de créer un admin
  depuis le formulaire d'inscription public.

Utilisation :
    python seed.py            # crée les données si la base est vide
    python seed.py --reset    # supprime tout et recrée les données
"""

import sys
from datetime import datetime, timedelta

from app import create_app
from extensions import db
from models import (
    User, Category, ProfessionalProfile, Skill, Evidence,
    Project, Review, TrustScore,
)
from utils import recalculate_trust_score

app = create_app()


# TrustHub s'adresse à TOUS les secteurs où la confiance doit se prouver avant
# d'entrer en relation avec quelqu'un — pas seulement le bâtiment. Les catégories
# sont regroupées par "sector", et chacune a un "type" qui détermine COMMENT
# la confiance se prouve (voir models.Category.category_type) :
#   - "prestataire" : la valeur se prouve par le TRAVAIL (qualité, délais,
#     fiabilité côté argent — ne pas disparaître après paiement).
#   - "vendeur"      : la valeur se prouve par le PRODUIT (qualité, prix abordable).
# (name, icon, sector, category_type)
CATEGORIES = [
    # --- Bâtiment & construction (prestataires) ----------------------------
    ("Architecte", "📐", "Bâtiment & Construction", "prestataire"),
    ("Maçon", "🧱", "Bâtiment & Construction", "prestataire"),
    ("Plombier", "🚰", "Bâtiment & Construction", "prestataire"),
    ("Électricien", "⚡", "Bâtiment & Construction", "prestataire"),
    ("Menuisier bois", "🪚", "Bâtiment & Construction", "prestataire"),
    ("Menuisier métallique / Soudeur", "🔩", "Bâtiment & Construction", "prestataire"),
    ("Peintre en bâtiment", "🎨", "Bâtiment & Construction", "prestataire"),
    ("Carreleur", "🀫", "Bâtiment & Construction", "prestataire"),
    ("Couvreur / Étanchéité", "🏠", "Bâtiment & Construction", "prestataire"),

    # --- Artisanat & réparation (prestataires) -----------------------------
    ("Réparateur électroménager", "🔧", "Artisanat & Réparation", "prestataire"),
    ("Mécanicien auto/moto", "🚗", "Artisanat & Réparation", "prestataire"),
    ("Couturier / Retoucheur", "🧵", "Artisanat & Réparation", "prestataire"),

    # --- Commerce & vente de produits (vendeurs) ---------------------------
    ("Vendeur de matériaux de construction", "🏗️", "Commerce & Vente", "vendeur"),
    ("Vendeur d'électroménager", "🧊", "Commerce & Vente", "vendeur"),
    ("Vendeur de véhicules", "🚙", "Commerce & Vente", "vendeur"),
    ("Boutique / Commerce général", "🛍️", "Commerce & Vente", "vendeur"),

    # --- Éducation & formation (prestataires) ------------------------------
    ("Professeur particulier", "📘", "Éducation & Formation", "prestataire"),
    ("Formateur professionnel", "🎓", "Éducation & Formation", "prestataire"),

    # --- Technologie & digital (prestataires) ------------------------------
    ("Développeur informatique", "💻", "Technologie & Digital", "prestataire"),
    ("Designer graphique", "🎨", "Technologie & Digital", "prestataire"),

    # --- Services à la personne (prestataires) ------------------------------
    ("Coiffeur / Esthéticienne", "💇", "Services à la personne", "prestataire"),
    ("Traiteur / Restauration", "🍽️", "Services à la personne", "prestataire"),
    ("Déménageur / Transport", "🚚", "Services à la personne", "prestataire"),
    ("Jardinier / Paysagiste", "🌿", "Services à la personne", "prestataire"),
]

# Pour un PRESTATAIRE, chaque avis est un tuple (qualite, respect_delais, fiabilite_paiement)
#   où fiabilite_paiement est True ("a bien terminé après paiement") ou False ("a disparu").
# Pour un VENDEUR, chaque avis est un tuple (qualite, prix_abordable).
PROFESSIONALS = [
    {
        "name": "Moussa Diop",
        "email": "moussa.diop@example.com",
        "phone": "+221771234501",
        "category": "Maçon",
        "location": "Dakar",
        "description": "Maçon spécialisé en construction et rénovation depuis plus de 12 ans. Travail soigné, respect des délais, toujours joignable après paiement.",
        "years": 12,
        "reviews": [(5, 5, True)] * 6 + [(4, 5, True)] * 2,
        "evidences": [
            ("photo", "Villa R+1 - Almadies", "acceptee"),
            ("photo", "Rénovation façade - Plateau", "acceptee"),
            ("certification", "Certificat de formation BTP", "acceptee"),
        ],
    },
    {
        "name": "Aïssatou Ba",
        "email": "aissatou.ba@example.com",
        "phone": "+221771234502",
        "category": "Développeur informatique",
        "location": "Dakar",
        "description": "Développeuse full-stack (Python, JavaScript). Livraisons fiables pour PME et startups.",
        "years": 6,
        "reviews": [(5, 4, True)] * 4 + [(4, 5, True)] * 2,
        "evidences": [
            ("document", "Portfolio de projets web", "acceptee"),
            ("temoignage", "Témoignage - Startup AgriTech", "acceptee"),
        ],
    },
    {
        "name": "Ibrahima Sarr",
        "email": "ibrahima.sarr@example.com",
        "phone": "+221771234503",
        "category": "Électricien",
        "location": "Thiès",
        "description": "Électricien bâtiment, installations neuves et dépannage rapide.",
        "years": 8,
        "reviews": [(4, 3, True)] * 3,
        "evidences": [
            ("photo", "Installation tableau électrique", "acceptee"),
        ],
    },
    {
        "name": "Fatou Ndiaye",
        "email": "fatou.ndiaye@example.com",
        "phone": "+221771234504",
        "category": "Professeur particulier",
        "location": "Dakar",
        "description": "Professeure de mathématiques, cours particuliers collège et lycée.",
        "years": 10,
        "reviews": [(5, 5, True)] * 8,
        "evidences": [
            ("certification", "Diplôme CAPES Mathématiques", "acceptee"),
            ("temoignage", "Témoignage - Parent d'élève", "acceptee"),
            ("temoignage", "Témoignage - Lycée Blaise Diagne", "acceptee"),
        ],
    },
    {
        "name": "Cheikh Fall",
        "email": "cheikh.fall@example.com",
        "phone": "+221771234505",
        "category": "Réparateur électroménager",
        "location": "Rufisque",
        "description": "Réparateur d'électroménager, nouveau sur la plateforme.",
        "years": 2,
        "reviews": [],
        "evidences": [
            ("photo", "Réparation réfrigérateur", "en_attente"),
        ],
    },
    {
        "name": "Awa Sow",
        "email": "awa.sow@example.com",
        "phone": "+221771234506",
        "whatsapp": "+221781234506",
        "category": "Vendeur de matériaux de construction",
        "location": "Dakar",
        "description": "Vend du ciment, du fer et des matériaux de construction de qualité contrôlée, à des prix compétitifs, avec livraison sur chantier.",
        "years": 5,
        "reviews": [(5, 4)] * 3 + [(4, 5)] * 2,
        "evidences": [
            ("document", "Registre de commerce", "acceptee"),
            ("temoignage", "Témoignage - Entreprise BTP locale", "acceptee"),
        ],
    },
    {
        # Exemple volontaire pour montrer le garde-fou "fiabilité paiement" :
        # un client déclare qu'il a disparu après avoir été payé. Le score
        # est automatiquement plafonné et le profil redevient "non vérifié"
        # (voir utils.recalculate_trust_score) jusqu'à examen par un admin
        # via /admin -> "Signalements de paiement".
        "name": "Modou Kane",
        "email": "modou.kane@example.com",
        "phone": "+221771234507",
        "category": "Plombier",
        "location": "Dakar",
        "description": "Plombier. Attention : un signalement de paiement est en cours de vérification sur ce profil (donnée de démonstration).",
        "years": 3,
        "reviews": [(4, 4, True), (2, 1, False)],
        "evidences": [
            ("photo", "Installation sanitaire", "acceptee"),
        ],
    },
]

DEMO_CLIENT = {"name": "Client Démo", "email": "client@trusthub.dev", "password": "client123"}
ADMIN = {"name": "Administrateur", "email": "admin@trusthub.dev", "password": "admin123"}
DEFAULT_PASSWORD = "demo1234"


def reset_database():
    db.drop_all()
    db.create_all()
    print("Base de données réinitialisée.")


def seed():
    # --- Catégories -------------------------------------------------------
    categories = {}
    for name, icon, sector, category_type in CATEGORIES:
        cat = Category.query.filter_by(name=name).first()
        if not cat:
            cat = Category(name=name, icon=icon, sector=sector, category_type=category_type)
            db.session.add(cat)
        categories[name] = cat
    db.session.commit()

    # --- Admin --------------------------------------------------------------
    if not User.query.filter_by(email=ADMIN["email"]).first():
        admin = User(name=ADMIN["name"], email=ADMIN["email"], role="admin")
        admin.set_password(ADMIN["password"])
        db.session.add(admin)

    # --- Client de démo -------------------------------------------------------
    if not User.query.filter_by(email=DEMO_CLIENT["email"]).first():
        client = User(name=DEMO_CLIENT["name"], email=DEMO_CLIENT["email"], role="client")
        client.set_password(DEMO_CLIENT["password"])
        db.session.add(client)
    db.session.commit()

    demo_client = User.query.filter_by(email=DEMO_CLIENT["email"]).first()

    # --- Professionnels de démonstration ------------------------------------
    for data in PROFESSIONALS:
        user = User.query.filter_by(email=data["email"]).first()
        if not user:
            user = User(
                name=data["name"],
                email=data["email"],
                role="professional",
                phone=data.get("phone"),
                whatsapp=data.get("whatsapp"),
            )
            user.set_password(DEFAULT_PASSWORD)
            db.session.add(user)
            db.session.commit()

        profile = user.professional_profile
        if not profile:
            profile = ProfessionalProfile(
                user_id=user.id,
                category_id=categories[data["category"]].id,
                location=data["location"],
                description=data["description"],
                years_experience=data["years"],
            )
            db.session.add(profile)
            db.session.commit()
        else:
            continue  # déjà seedé précédemment, on ne duplique pas

        is_vendor = categories[data["category"]].category_type == "vendeur"

        # Preuves
        for ev_type, title, status in data["evidences"]:
            evidence = Evidence(
                professional_id=profile.id,
                evidence_type=ev_type,
                title=title,
                status=status,
                reviewed_at=datetime.utcnow() if status != "en_attente" else None,
            )
            db.session.add(evidence)
        db.session.commit()

        # Prestations + avis (chaque avis DOIT passer par un Project confirmé,
        # exactement comme le ferait un vrai client, pour rester cohérent
        # avec la règle métier "un avis = une preuve de prestation réelle")
        for i, review_data in enumerate(data["reviews"]):
            project = Project(
                client_id=demo_client.id,
                professional_id=profile.id,
                description=f"{'Commande' if is_vendor else 'Prestation'} de démonstration #{i + 1}",
                status="confirmee",
                created_at=datetime.utcnow() - timedelta(days=30 - i),
                accepted_at=datetime.utcnow() - timedelta(days=29 - i),
                confirmed_at=datetime.utcnow() - timedelta(days=28 - i),
            )
            db.session.add(project)
            db.session.commit()

            if is_vendor:
                qualite, prix_abordable = review_data
                review = Review(project_id=project.id, qualite=qualite, prix_abordable=prix_abordable)
            else:
                qualite, respect_delais, fiabilite_paiement = review_data
                review = Review(
                    project_id=project.id,
                    qualite=qualite,
                    respect_delais=respect_delais,
                    fiabilite_paiement=fiabilite_paiement,
                )
            db.session.add(review)
            project.status = "avis_laisse"
            db.session.commit()

        recalculate_trust_score(profile)

    print("Données de démonstration créées avec succès.")
    print(f"  Admin  : {ADMIN['email']} / {ADMIN['password']}")
    print(f"  Client : {DEMO_CLIENT['email']} / {DEMO_CLIENT['password']}")
    print(f"  Pros   : (voir liste ci-dessus) / mot de passe = {DEFAULT_PASSWORD}")
    print("  Exemple de signalement de paiement : modou.kane@example.com (voir /admin)")


if __name__ == "__main__":
    with app.app_context():
        if "--reset" in sys.argv:
            reset_database()
        seed()
