// TrustHub — JS minimal, volontairement sans framework pour rester léger sur mobile.

document.addEventListener("DOMContentLoaded", () => {
  // Fait disparaître automatiquement les messages flash après quelques secondes,
  // pour ne pas encombrer l'écran (précieux sur mobile).
  const flashes = document.querySelectorAll(".flash");
  flashes.forEach((el, i) => {
    setTimeout(() => {
      el.style.transition = "opacity 0.4s ease";
      el.style.opacity = "0";
      setTimeout(() => el.remove(), 400);
    }, 4000 + i * 300);
  });

  // Aperçu immédiat du fichier choisi lors de l'ajout d'une preuve,
  // pour rassurer l'utilisateur qu'il a bien sélectionné la bonne image.
  const fileInput = document.querySelector('input[type="file"]');
  if (fileInput) {
    fileInput.addEventListener("change", () => {
      const hint = fileInput.parentElement.querySelector(".field-hint");
      if (fileInput.files.length > 0 && hint) {
        hint.textContent = `Fichier sélectionné : ${fileInput.files[0].name}`;
      }
    });
  }

  // Confirmation avant les actions destructrices/irréversibles (refuser une preuve, etc.)
  document.querySelectorAll("form.confirm-before-submit").forEach((form) => {
    form.addEventListener("submit", (e) => {
      if (!confirm("Confirmer cette action ?")) {
        e.preventDefault();
      }
    });
  });

  initInstallBanner();
});

// ---------------------------------------------------------------------------
// PWA : bannière d'installation + enregistrement du service worker
// ---------------------------------------------------------------------------

function initInstallBanner() {
  const banner = document.getElementById("install-banner");
  const text = document.getElementById("install-banner__text");
  const actionBtn = document.getElementById("install-banner__action");
  const dismissBtn = document.getElementById("install-banner__dismiss");
  if (!banner) return;

  // Ne plus jamais réafficher la bannière une fois fermée ou installée
  // dans cette session (in-memory only : voir la contrainte artifacts,
  // mais ici on est dans une vraie page servie par Flask, localStorage
  // est donc disponible et approprié pour "ne pas insister" d'une visite à l'autre).
  const DISMISS_KEY = "trusthub_install_dismissed";
  const alreadyDismissed = () => {
    try {
      return localStorage.getItem(DISMISS_KEY) === "1";
    } catch (e) {
      return false;
    }
  };
  const markDismissed = () => {
    try {
      localStorage.setItem(DISMISS_KEY, "1");
    } catch (e) {
      /* stockage indisponible (navigation privée...) : tant pis, pas bloquant */
    }
  };

  const isStandalone =
    window.matchMedia("(display-mode: standalone)").matches ||
    window.navigator.standalone === true; // Safari iOS

  if (isStandalone || alreadyDismissed()) {
    banner.hidden = true;
  } else {
    const isIOS = /iphone|ipad|ipod/i.test(window.navigator.userAgent);

    if (isIOS) {
      // Safari iOS ne déclenche jamais "beforeinstallprompt" : on ne peut
      // qu'expliquer le geste manuel (Partager -> Sur l'écran d'accueil).
      text.textContent =
        "Pour installer TrustHub : appuyez sur Partager, puis \"Sur l'écran d'accueil\".";
      actionBtn.hidden = true;
      banner.hidden = false;
    } else {
      // Android/Chrome/Edge : on attend l'événement natif avant de montrer
      // quoi que ce soit, pour ne jamais promettre une installation impossible.
      window.addEventListener("beforeinstallprompt", (event) => {
        event.preventDefault();
        banner.hidden = false;
        actionBtn.onclick = async () => {
          banner.hidden = true;
          event.prompt();
          await event.userChoice;
          markDismissed();
        };
      });
    }
  }

  dismissBtn.addEventListener("click", () => {
    banner.hidden = true;
    markDismissed();
  });

  window.addEventListener("appinstalled", () => {
    banner.hidden = true;
    markDismissed();
  });
}

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    // Servi depuis la racine (/sw.js), pas /static/sw.js, pour que le scope
    // couvre toute l'application (voir routes/main.py -> service_worker()).
    navigator.serviceWorker.register("/sw.js").catch((err) => {
      console.warn("Échec de l'enregistrement du service worker :", err);
    });
  });
}
