// TrustHub — Service Worker
//
// Objectif volontairement modeste pour ce MVP : faire fonctionner l'app comme
// une PWA installable (icône, écran de démarrage, pas de barre d'adresse) et
// éviter un écran blanc si la connexion est mauvaise, PAS synchroniser des
// données hors-ligne (ça viendrait avec IndexedDB + Background Sync, hors
// périmètre du MVP — voir README).
//
// Stratégie :
// - Fichiers statiques (css/js/icônes/manifest) : "cache d'abord" (rapide,
//   changent rarement — on incrémente CACHE_NAME pour forcer un rafraîchissement).
// - Pages HTML : "réseau d'abord" (on veut toujours les derniers avis/scores),
//   avec repli sur le cache puis sur /offline si vraiment rien n'est disponible.

const CACHE_NAME = "trusthub-cache-v1";

const APP_SHELL = [
  "/static/css/style.css",
  "/static/js/main.js",
  "/static/manifest.json",
  "/static/icons/icon-192.png",
  "/static/icons/icon-512.png",
  "/offline",
];

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;

  // On ne met en cache que les requêtes GET : les formulaires (POST) doivent
  // toujours atteindre le serveur, sans quoi une demande, un avis ou une
  // validation admin pourrait sembler fonctionner alors qu'elle a échoué.
  if (request.method !== "GET") return;

  const url = new URL(request.url);

  // Fichiers statiques : cache d'abord, réseau en secours.
  if (url.pathname.startsWith("/static/")) {
    event.respondWith(
      caches.match(request).then((cached) => cached || fetch(request))
    );
    return;
  }

  // Pages : réseau d'abord (toujours les données à jour), cache en secours,
  // page /offline si vraiment aucune connexion et rien en cache.
  event.respondWith(
    fetch(request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
        return response;
      })
      .catch(() =>
        caches
          .match(request)
          .then((cached) => cached || caches.match("/offline"))
      )
  );
});
