import io
import os
import uuid
from datetime import datetime

from flask import current_app
from PIL import Image, UnidentifiedImageError
from werkzeug.utils import secure_filename

from extensions import db
from models import TrustScore, Review, Project

IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}


def allowed_file(filename):
    """
    Vérifie l'extension du fichier AVANT tout traitement. C'est une première
    barrière de sécurité simple : on n'accepte que des formats connus
    (images et PDF), jamais de scripts exécutables (.php, .exe, .sh...).
    Ce n'est qu'une PREMIÈRE barrière : voir save_uploaded_file() pour la
    vérification du contenu réel du fichier, qui est la protection qui compte.
    """
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_EXTENSIONS"]


def save_uploaded_file(file_storage):
    """
    Sauvegarde un fichier uploadé de façon sûre :
    - secure_filename() supprime tout caractère dangereux (../, espaces, etc.)
    - un préfixe uuid4 évite que deux utilisateurs écrasent le même fichier
      en uploadant un fichier du même nom (ex: "photo.jpg").
    - le CONTENU réel du fichier est vérifié, pas seulement son extension :
      une extension ".jpg" ne prouve rien, un fichier peut très bien être
      autre chose (script, exécutable renommé, fichier "polyglotte" valide
      à la fois comme image et comme page HTML/JS piégée). Pour les images,
      on les décode puis on les RÉ-ENCODE avec Pillow avant de les stocker :
      un fichier qui n'est pas une vraie image est rejeté, et toute donnée
      cachée dans le fichier d'origine (au-delà des pixels) disparaît au
      passage. Pour les PDF, on vérifie au moins la signature binaire (les
      4 premiers octets d'un PDF valide sont toujours "%PDF").
    Retourne le nom de fichier final (à stocker en base), ou None si rien à faire.
    """
    if not file_storage or file_storage.filename == "":
        return None
    if not allowed_file(file_storage.filename):
        raise ValueError("Type de fichier non autorisé.")

    ext = file_storage.filename.rsplit(".", 1)[1].lower()
    safe_name = secure_filename(file_storage.filename)
    unique_name = f"{uuid.uuid4().hex}_{safe_name}"
    destination = os.path.join(current_app.config["UPLOAD_FOLDER"], unique_name)

    raw = file_storage.read()
    if not raw:
        raise ValueError("Le fichier est vide.")

    if ext in IMAGE_EXTENSIONS:
        try:
            # Image.open() + verify() confirme que le contenu est bien une
            # image décodable (rejette un exécutable/script renommé). On doit
            # rouvrir un second flux ensuite car verify() épuise le premier.
            Image.open(io.BytesIO(raw)).verify()
            image = Image.open(io.BytesIO(raw))
            image = image.convert("RGB") if image.mode not in ("RGBA", "LA") else image
            image.save(destination)
        except UnidentifiedImageError:
            raise ValueError("Le fichier n'est pas une image valide.")
        except Exception:
            # Inclut PIL.Image.DecompressionBombError (image aux dimensions
            # absurdes, potentielle attaque par déni de service) et toute
            # autre erreur de décodage : dans tous les cas, on refuse le fichier
            # plutôt que de laisser une exception remonter jusqu'à l'utilisateur.
            raise ValueError("Impossible de traiter cette image.")
    else:  # pdf
        if not raw.startswith(b"%PDF"):
            raise ValueError("Le fichier n'est pas un PDF valide.")
        with open(destination, "wb") as f:
            f.write(raw)

    return unique_name


def recalculate_trust_score(professional_profile):
    """
    Recalcule le score de confiance d'un professionnel à partir de TOUS
    les avis liés à ses prestations confirmées.

    Les critères ne sont PAS les mêmes pour tout le monde (voir Category.category_type
    et Review) :

    - PRESTATAIRE (maçon, développeur, professeur...) : la valeur se prouve par
        1) la qualité du travail,
        2) le respect des délais,
        3) la fiabilité côté argent : une fois payé, a-t-il bien terminé le
           travail sans disparaître ? C'est un signal factuel (oui/non), pas
           une note d'opinion — et le plus important des trois : une seule
           réponse "non" déclenche un signalement grave qui plafonne le score
           et repasse le profil en "non vérifié" jusqu'à examen par un admin
           (voir ProfessionalProfile.payment_complaint_flag).

    - VENDEUR (boutique, revendeur de matériaux...) : la valeur se prouve par
        1) la qualité des produits vendus,
        2) des prix abordables.

    Chaque critère renseigné est converti en pourcentage (note / 5 * 100), puis
    moyenné sur tous les avis. Le score global est la moyenne des critères
    pertinents pour ce type de profil, plus un petit bonus de crédibilité lié
    aux preuves validées par un admin (jusqu'à +5 points, plafonné à 100).
    """
    reviews = (
        Review.query.join(Project, Review.project_id == Project.id)
        .filter(Project.professional_id == professional_profile.id)
        .all()
    )

    is_vendor = professional_profile.is_vendor()
    qualite_pct = delais_pct = fiabilite_paiement_pct = prix_pct = None
    has_payment_complaint = False

    if reviews:
        n = len(reviews)
        qualite_pct = sum(r.qualite for r in reviews) / n / 5 * 100

        if is_vendor:
            prix_scores = [r.prix_abordable for r in reviews if r.prix_abordable is not None]
            if prix_scores:
                prix_pct = sum(prix_scores) / len(prix_scores) / 5 * 100
            parts = [p for p in [qualite_pct, prix_pct] if p is not None]
        else:
            delais_scores = [r.respect_delais for r in reviews if r.respect_delais is not None]
            if delais_scores:
                delais_pct = sum(delais_scores) / len(delais_scores) / 5 * 100

            # Si un signalement a déjà été levé par un admin, on ne réévalue
            # ce critère qu'à partir des avis postérieurs à la levée : un
            # signalement résolu ne doit pas réapparaître automatiquement à
            # chaque nouvel avis ou nouvelle preuve validée.
            cleared_at = professional_profile.payment_complaint_cleared_at
            paiement_reviews = (
                [r for r in reviews if cleared_at is None or r.created_at > cleared_at]
            )
            paiement_flags = [r.fiabilite_paiement for r in paiement_reviews if r.fiabilite_paiement is not None]
            if paiement_flags:
                fiabilite_paiement_pct = sum(1 for f in paiement_flags if f) / len(paiement_flags) * 100
                has_payment_complaint = any(f is False for f in paiement_flags)

            parts = [p for p in [qualite_pct, delais_pct, fiabilite_paiement_pct] if p is not None]

        base_score = sum(parts) / len(parts) if parts else 0

        evidence_bonus = min(professional_profile.verified_evidence_count() * 1, 5)
        global_score = min(base_score + evidence_bonus, 100)

        # Un client qui déclare qu'un prestataire a disparu après paiement est
        # le signal le plus grave que TrustHub puisse recevoir : la confiance
        # ne peut pas se "moyenner" avec de bons avis passés. Le score est
        # plafonné bas tant qu'un administrateur n'a pas examiné le signalement.
        if has_payment_complaint:
            global_score = min(global_score, 30)
    else:
        global_score = 0

    professional_profile.payment_complaint_flag = has_payment_complaint

    score = professional_profile.trust_score
    if score is None:
        score = TrustScore(professional_id=professional_profile.id)
        db.session.add(score)

    score.qualite_pct = round(qualite_pct, 1) if qualite_pct is not None else 0
    score.delais_pct = round(delais_pct, 1) if delais_pct is not None else None
    score.fiabilite_paiement_pct = round(fiabilite_paiement_pct, 1) if fiabilite_paiement_pct is not None else None
    score.prix_pct = round(prix_pct, 1) if prix_pct is not None else None
    score.global_score = round(global_score, 1)
    score.updated_at = datetime.utcnow()

    update_verification_status(professional_profile)
    db.session.commit()


def update_verification_status(professional_profile):
    """
    Fait évoluer automatiquement le statut du professionnel selon les règles
    métier de TrustHub (voir README, section "Système de vérification") :

      non_verifie -> verifie     : dès qu'au moins 1 preuve a été validée par un admin
      verifie     -> recommande  : dès que 5 prestations ont été confirmées par des clients
                                    ET que le score global dépasse 80/100

    On ne rétrograde jamais automatiquement un statut ici — SAUF dans un cas :
    un signalement de paiement actif (payment_complaint_flag) repasse toujours
    le profil en "non_verifie", quels que soient ses avis précédents. Ce n'est
    qu'un administrateur qui peut lever ce signalement depuis /admin, après
    vérification, ce qui permet au statut de progresser de nouveau normalement.
    """
    if professional_profile.payment_complaint_flag:
        professional_profile.status = "non_verifie"
        return

    has_validated_evidence = professional_profile.verified_evidence_count() > 0
    completed_projects = professional_profile.completed_projects_count()
    score = professional_profile.trust_score.global_score if professional_profile.trust_score else 0

    if professional_profile.status == "non_verifie" and has_validated_evidence:
        professional_profile.status = "verifie"

    if professional_profile.status == "verifie" and completed_projects >= 5 and score >= 80:
        professional_profile.status = "recommande"
