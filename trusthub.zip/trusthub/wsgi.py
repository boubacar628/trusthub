"""
wsgi.py — Point d'entrée pour les hébergeurs qui attendent une variable nommée
"application" (c'est le cas de PythonAnywhere : voir README, section déploiement).

Sur Render/Railway, on utilise plutôt directement `gunicorn app:app` (voir
Procfile), donc ce fichier n'est utile QUE pour PythonAnywhere. Il définit
aussi ici les variables d'environnement de production, car PythonAnywhere
(sur son offre gratuite) ne propose pas d'interface dédiée aux variables
d'environnement comme Render : c'est donc ce fichier, édité une seule fois
dans leur éditeur web, qui joue ce rôle.
"""

import os

# --- Variables d'environnement de production ---------------------------
# À personnaliser lors du déploiement (voir README) : remplacez la valeur de
# SECRET_KEY par une chaîne aléatoire unique, générée une seule fois.
os.environ.setdefault("SECRET_KEY", "CHANGEZ-MOI-avec-une-chaine-aleatoire-unique")
os.environ.setdefault("FORCE_SECURE_COOKIES", "true")  # PythonAnywhere sert en HTTPS

from app import app as application  # noqa: E402  (import après les variables d'environnement, volontairement)
